from django.contrib import admin
from task_app.models import laptops,phones,Pcs

# Register your models here.
admin.site.register(laptops)
admin.site.register(phones)
admin.site.register(Pcs)
