from django import forms
from django.contrib.auth.models import User

class user_info(forms.ModelForm):
    confirm_password = forms.CharField(widget=forms.PasswordInput())
    class Meta():
        model = User    
        fields = ['first_name','last_name','username','email','password','confirm_password']

    def clean(self):
        data = super().clean()

        pass1 = data['password']
        pass2 = data['confirm_password']

        if pass1 != pass2:
            raise forms.ValidationError("Password won't match..!!")


