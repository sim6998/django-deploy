from django.shortcuts import render
from django.http import HttpResponse
from task_app.forms import user_info
from task_app.models import laptops,phones,Pcs
from django.contrib.auth import authenticate,login,logout
from django.contrib.auth.decorators import login_required


# Create your views here.

def index(request):
    return render(request,'html/index.html')

def register(request):
    reg = False
    
    if request.method == "POST":
        fm = user_info(request.POST)

        if fm.is_valid():
            reg_form =  fm.save(commit=True)
            reg_form.set_password(reg_form.password)
            reg_form.save()
            reg = True

            return render(request,'html/registration.html',{'registerd':reg})
        else:
            return HttpResponse('Registration Form Not Valid')
    else:
        fm = user_info()

    context = {
        'register':fm,
        'registerd':reg,
    }
    return render(request,'html/registration.html',context=context)


def user_login(request):
    
    if request.method == "POST":
        username = request.POST.get('user_name')
        password = request.POST.get('pass')

        print('username : ',username)
        print('Password : ',password)

        user = authenticate(username=username,password=password)

        if user:
            if user.is_active:
                login(request,user)
                return render(request,'html/index.html')
            else:
                return HttpResponse('User Not Active..!!')
        else:
            return HttpResponse('User Not Found Plz Register user..!!')
    else:
        return render(request,'html/login.html')

@login_required
def user_logout(request):
    logout(request)
    return render(request,'html/index.html')

@login_required
def laptop(request):
  
    laptop_data = laptops.objects.all()

    context = {
        'laptops':laptop_data,
    }        

    return render(request,'html/laptop.html',context=context)

def contain(request):
    return render(request,'html/contain.html')


@login_required
def add_laptop(request):
    
    if request.method == "POST":
        model = request.POST.get('model_name')
        price = request.POST.get('price')
        features = request.POST.get('features')
        status = request.POST.get('status_menu')
        
        laptops.objects.create(model_name=model,price=price,features=features,status=status)

        return render(request,'html/index.html')
    else:
        return render(request,'html/add_laptop.html')

@login_required
def smart_phone(request):
    smartphones = phones.objects.all()

    context = {
        'phones':smartphones,
    }
    return render(request,'html/smart_phone.html',context=context)

@login_required
def add_smart_phone(request):

    if request.method == "POST":
        smartphone_name = request.POST.get('model_name')
        company = request.POST.get('company_name')
        price = request.POST.get('price')
        features = request.POST.get('features')
        status = request.POST.get('status_menu')

        phones.objects.create(smartphone_name=smartphone_name,company_name=company,price=price,features=features,status=status)
        return render(request,'html/index.html')

    else:
        return render(request,'html/add_phones.html')

@login_required
def pc(request):
    pc_details = Pcs.objects.all()

    context = {
        'pcs':pc_details,
    }
    return render(request,'html/pc.html',context=context)

@login_required
def add_pc(request):
    if request.method == "POST":
        model = request.POST.get('model_name')
        price = request.POST.get('price')
        features = request.POST.get('features')
        status = request.POST.get('status_menu')
        
        Pcs.objects.create(model_name=model,price=price,features=features,status=status)

        return render(request,'html/index.html')
    else:
        return render(request,'html/add_pc.html')