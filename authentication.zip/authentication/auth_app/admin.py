from django.contrib import admin
from auth_app.models import UserProfileModel

# Register your models here.
admin.site.register(UserProfileModel)
