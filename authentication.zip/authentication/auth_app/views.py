from django.shortcuts import render
from auth_app.forms import UserProfile,UserProfileInfo

from django.contrib.auth import authenticate,login,logout
from django.contrib.auth.decorators import login_required
from django.http import HttpResponse,HttpResponseRedirect

# Create your views here.


def index(request):
    return render(request,'htmls/index.html')

def registration(request):
    
    registerd = False

    if request.method == "POST":
        users = UserProfile(data=request.POST)
        profiles = UserProfileInfo(data=request.POST)

        if users.is_valid() and profiles.is_valid():
            user = users.save()
            user.set_password(user.password)
            user.save()
            
            profile = profiles.save(commit=False)
            profile.user = user
            
            if 'profile_img' in request.FILES:
                profile.profile_img = request.FILES['profile_img']
            profile.save()
            registerd = True 
            return render(request,'htmls/registration.html',{'registered':registerd})
        else:
            print(users.errors,profiles.errors)
    else:
        users = UserProfile()
        profiles = UserProfileInfo()

    context = {
        'user':users,
        'profile':profiles,
        'registerd':registerd,
    }

    return render(request,'htmls/registration.html',context=context)

def login_func(request):
    if request.method == "POST":
        username = request.POST.get('user')
        password = request.POST.get('pass')
        print('username : ',username)
        print('password : ',password)
        user = authenticate(username=username,password=password)
        print(user)
        if user:
            if user.is_active:
                login(request,user)
                return render(request,'htmls/index.html')
            else:
                return HttpResponse('User Not Active..!!')
        else:
            return HttpResponse('User Not Found..!!')
    else:
        return render(request,'htmls/login.html')

@login_required
def logout_func(request):
    logout(request)
    return render(request,'htmls/index.html')

@login_required
def special(request):
    return HttpResponse('You are Logged in..!!')